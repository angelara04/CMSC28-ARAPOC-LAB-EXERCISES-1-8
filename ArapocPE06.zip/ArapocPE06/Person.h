// Person.h

#ifndef PERSON_H  
#define PERSON_H
#include <iostream>
#include <string>
#include <list>

using namespace std;

//Person class definition
class Person {
	//Declaration of private member variables
    string fname, lname, gender;

public:
    // Constructor for fname, lname, and gender initialization
    Person(string fname, string lname, string gender) : fname(fname), lname(lname), gender(gender) {}

    // Getter methods
    string getFname() { return fname; }
    string getLname() { return lname; }
    string getGender() { return gender; }
};

#endif
