// Movie.h 

#ifndef MOVIE  // Prevents the header file from being included more than once
#define MOVIE
#include <string>
#include <list>
#include "Person.h"  // Include the Person header file because Class Movie has two member attributes from this file
using namespace std;

//Movie class definition
class Movie {
    // Declaration of private member variables
    string title, synopsis, mpaa_rating;
    list<string> genres;  // List of genres
    list<Person> directors, actors;  // Lists of directors and actors

public:
    // Constructor for  title, synopsis, and mpaa_rating
    Movie(string title, string synopsis, string mpaa_rating) : title(title), synopsis(synopsis), mpaa_rating(mpaa_rating) {}

    // Method for adding to genres list
    void addGenre(string genre) { genres.push_back(genre); }

    // Method for adding to the directors list
    void addDirector(Person director) { directors.push_back(director); }

    // Method for adding to the actors list
    void addActor(Person actor) { actors.push_back(actor); }

    // Getter methods
    string getTitle() { return title; }
    string getSynopsis() { return synopsis; }
    string getMpaaRating() { return mpaa_rating; }
    list<string> getGenres() { return genres; }
    list<Person> getDirectors() { return directors; }
    list<Person> getActors() { return actors; }
};

#endif  
