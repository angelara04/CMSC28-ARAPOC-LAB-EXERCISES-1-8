// Submitted by: Angel Grace P. Arapoc
// Programming Exercise 06 - OOP 2 Activity 3
// May 17, 2024
#include <iostream>
#include <string>
#include <list>
#include <sstream>
#include "Person.h"  // Include the Person header file
#include "Movie.h"  // Include the Movie header file

using namespace std;

int main() {
    // Declaration of variables for storing input
    string title, synopsis, mpaa_rating, genre, fname, lname, gender;

    // Asks user for movie details
    cout << "This program will ask for information about a movie of your choice!\n" << endl;
    cout << "Enter Movie Title: ";
    getline(cin, title);

    cout << "Enter Synopsis: ";
    getline(cin, synopsis);

    cout << "What is its MPAA Rating: ";
    getline(cin, mpaa_rating);

    // Create a new Movie object with the entered details
    Movie movie(title, synopsis, mpaa_rating);



	cout << "What is the Genre(comma separated): ";
	getline(cin, genre);
	stringstream ss(genre);
while (getline(ss, genre, ',')) {
    // Trim leading and trailing spaces from genre
    genre.erase(0, genre.find_first_not_of(' ')); // leading spaces
    genre.erase(genre.find_last_not_of(' ') + 1); // trailing spaces

    movie.addGenre(genre);
}
    // Loop to add multiple directors to the movie
    char directorsList = 'y';
    while (directorsList == 'y' || directorsList == 'Y') {
        // Asks user for director details
        cout << "Who is the Director (First name): ";
        getline(cin, fname);
        cout << "Who is the Director (Last name):";
        getline(cin, lname);
        cout << "Enter Director's Gender: ";
        getline(cin, gender);

        // Create a new object with the details and add it as a director
        Person director(fname, lname, gender);
        movie.addDirector(director);

        cout << "Do you want to add another director? (y/n): ";
        cin >> directorsList;
        cin.ignore();  // To clear the newline character from the input buffer
    }

    // Loop to add multiple actors to the movie
    char actorsList = 'y';
    while (actorsList == 'y' || actorsList == 'Y') {
    	
        // Asks user for actor details
        cout << "Who is the Actor/actress (First name):: ";
        getline(cin, fname);
        cout << "Who is the Actor/actress (Last name):: ";
        getline(cin, lname);
        cout << "Enter Actor's Gender: ";
        getline(cin, gender);

        // Create a new object with the details and add it as an actor
        Person actor(fname, lname, gender);
        movie.addActor(actor);

        cout << "Do you want to add another actor? (y/n): ";
        cin >> actorsList;
        cin.ignore();  // Clear the newline character from the input buffer
    }

    // Display movie details
    cout << "\nMOVIE DETAILS\n";
    cout << "\nMovie Title: " << movie.getTitle() << "\n";
    cout << "\nSynopsis: " << movie.getSynopsis() << "\n";
    cout << "\nMPAA Rating: " << movie.getMpaaRating() << "\n";
	cout << "\nGenres: ";
	list<string> genres = movie.getGenres();
	for (list<string>::iterator it = genres.begin(); it != genres.end(); ++it) {
	    cout << *it << "\t";
}
    cout << "\n\nDirectors:\n";
    list<Person> directors = movie.getDirectors();
    for (list<Person>::iterator it = directors.begin(); it != directors.end(); ++it) {
        cout << it->getFname() << " " << it->getLname() << "\n";
    }

    cout << "\nActors:\n";
    list<Person> actors = movie.getActors();
    for (list<Person>::iterator it = actors.begin(); it != actors.end(); ++it) {
        cout << it->getFname() << " " << it->getLname() << "\n";
    }

    return 0;
}
