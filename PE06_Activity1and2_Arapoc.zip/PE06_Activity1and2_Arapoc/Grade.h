//Angel Grace P. Arapoc CMSC 28 Laborator Exercise
// May 15, 2024 Activity 2


#ifndef GRADE_H
#define GRADE_H

#include <iostream>

class GradeEvaluator {
public:
    static void evaluateGrade(float grade) { // Change to float
        std::cout << "Grade: " << grade << std::endl;
        if (grade >= 60.0f) { //float comparison
            std::cout << "Evaluation: Pass" << std::endl;
        } else {
            std::cout << "Evaluation: Fail" << std::endl;
        }
    }
};

#endif

