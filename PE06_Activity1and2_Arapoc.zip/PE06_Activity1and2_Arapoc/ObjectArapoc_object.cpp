//Angel Grace P. Arapoc CMSC 28 Laborator Exercise
// May 15, 2024 Activity 1.2

#include <iostream>
#include "ObjectArapoc.h" //including header file ObjectArapoc.h

//Main function
int main(){
	ObjectArapoc obj(3, 'a', 9.54);
	obj.display();
	return 0;
}
