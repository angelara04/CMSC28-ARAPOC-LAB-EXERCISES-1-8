//Angel Grace P. Arapoc CMSC 28 Laborator Exercise
// May 15, 2024 Activity1.1

#include <iostream>

using namespace std;

//Class
class ObjectArapoc{
	private: 
	//Declaration of object features
		int feature1;
		char feature2;
		float feature3; 
	
	public:
		
		//function for setting feature values
		ObjectArapoc(int a, char b, float c){
			feature1 = a;
			feature2 = b;
			feature3 = c;
			
		}
		//Display function
		void display(){
			
			cout <<"Feature 1: " << feature1 << endl;
			cout <<"Feature 2: " <<	feature2 << endl;
			cout <<"Feature 3: " << feature3 << endl;
		}
		
};

//Main function
int main(){
	ObjectArapoc obj(3,'a', 9.54);
	obj.display();
	return 0;
}
