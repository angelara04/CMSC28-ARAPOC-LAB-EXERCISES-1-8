// Angel Grace P. Arapoc CMSC 28 Laboratory Exercise
// May 15, 2024 Activity 2

#ifndef PERSON_H
#define PERSON_H

#include <iostream>
using namespace std;

class Person {
private:
    int age;       // Age of the person
    char gender;   // Gender of the person

public:
    // Default constructor
    Person() : age(0), gender('M') {}

    // Constructor with age parameter
    Person(int newage) : age(newage), gender('M') {}

    // Constructor with age and gender parameters
    Person(int newage, char c) : age(newage), gender(c) {}

    // Setter for age with validation
    void setage(int newage) {
        if (newage >= 0) {
            age = newage;
        } else {
            cout << "Invalid age!!!" << endl;
        }
    }

    // Getter for age
    int getage() const {
        return age;
    }

    // Setter for gender with validation
    void setgender(char c) {
        if (c == 'M' || c == 'F') {
            gender = c;
        } else {
            cout << "Invalid gender!!!" << endl;
        }
    }

    // Getter for gender
    char getgender() const {
        return gender;
    }

    // View functions to display person's details
    void view() const {
        cout << "Person age is = " << getage() << endl;
        cout << "Person gender is = " << getgender() << endl;
    }

    void view(int age) const {
        cout << "Person age is = " << age << endl;
        cout << "Person gender is = " << gender << endl;
    }

    void view(int age, char gender) const {
        cout << "Person age is = " << age << endl;
        cout << "Person gender is = " << gender << endl;
    }
};

#endif

