//Angel Grace P. Arapoc
//BSCS CMSC 28 Programming Exercise 07 - OOP 3 Inheritance and Encapsulation
// May 22, 2024
// File: ProductInventory.h
#include <iostream>
#include <string>
using namespace std;

class Product {
private:
    string name;
    string brand;
    double price;
    int quantity;
    string description;
    string category;
    string color;

public:
    Product() {}
    Product(string _name, string _brand, double _price, int _quantity, string _description, string _category, string _color) {
        name = _name;
        brand = _brand;
        price = _price;
        quantity = _quantity;
        description = _description;
        category = _category;
        color = _color;
    }

    // Setters and Getters for each attribute
    void setName(string _name) { name = _name; }
    string getName() { return name; }

    void setBrand(string _brand) { brand = _brand; }
    string getBrand() { return brand; }

    void setPrice(double _price) { 
    price = _price;
    }
    double getPrice() { return price; }

    void setQuantity(int _quantity) { 
        quantity = _quantity;
    }
    int getQuantity() { return quantity; }

    void setDescription(string _description) { description = _description; }
    string getDescription() { return description; }

    void setCategory(string _category) { category = _category; }
    string getCategory() { return category; }

    void setColor(string _color) { color = _color; }
    string getColor() { return color; }
};

class Clothing : public Product {
private:
    string material;
    string size;

public:
    Clothing() {}
    Clothing(string _name, string _brand, double _price, int _quantity, string _description, string _category, string _color, string _material, string _size)
        : Product(_name, _brand, _price, _quantity, _description, _category, _color) {
        material = _material;
        size = _size;
    }

    // Setters and Getters for each attribute
    void setMaterial(string _material) { material = _material; }
    string getMaterial() { return material; }

    void setSize(string _size) { size = _size; }
    string getSize() { return size; }
};

class Electronics : public Product {
private:
    string model;
    string warranty;
    string technicalSpecifications;

public:
    Electronics() {}
    Electronics(string _name, string _brand, double _price, int _quantity, string _description, string _category, string _color, string _model, string _warranty, string _technicalSpecifications)
        : Product(_name, _brand, _price, _quantity, _description, _category, _color) {
        model = _model;
        warranty = _warranty;
        technicalSpecifications = _technicalSpecifications;
    }

    // Setters and Getters for each attribute
    void setModel(string _model) { model = _model; }
    string getModel() { return model; }

    void setWarranty(string _warranty) { warranty = _warranty; }
    string getWarranty() { return warranty; }

    void setTechnicalSpecifications(string _technicalSpecifications) { technicalSpecifications = _technicalSpecifications; }
    string getTechnicalSpecifications() { return technicalSpecifications; }
};