//Angel Grace P. Arapoc
//BSCS CMSC 28 Programming Exercise 07 - OOP 3 Inheritance and Encapsulation
//May 22, 2024

#include <iostream>
#include <limits> // for error trapping and limits in input
#include "ProductInventory.h" //include the header file
using namespace std;

// Function to validate positive float input
float validatePositiveFloatInput(string attribute) {
    float value;
    while (true) {
        cout << "Enter " << attribute << " :";
        if (!(cin >> value) || value < 0) {
            cout << "Invalid input. Please enter a valid positive floating-point number." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        } else {
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
            return value;
        }
    }
}

// Function to validate positive integer input
int validatePositiveIntegerInput(string attribute) {
    int value;
    while (true) {
        cout << "Enter " << attribute << " :";
        if (!(cin >> value) || value < 0) {
            cout << "Invalid input. Please enter a valid positive integer." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        } else {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return value;
        }
    }
}

int main() {
    // Declare variables for product details
    string name, brand, description, category, color, material, size, model, warranty, technicalSpecifications;
    double price;
    int quantity;
    char productType;

    // Prompt user to enter product type
    cout << "Enter product type (C for Clothing, E for Electronics): ";
    cin >> productType;
    cin.ignore();  // Ignore remaining newline character

    // Process Clothing type of product
    if (productType == 'C' || productType == 'c') {
        // Input product details
        cout << "Enter product name: ";
        getline(cin, name);
        cout << "Enter product brand: ";
        getline(cin, brand);
        price = validatePositiveFloatInput("product price");
        quantity = validatePositiveIntegerInput("product quantity");
        cout << "Enter product description: ";
        getline(cin, description);
        cout << "Enter product category: ";
        getline(cin, category);
        cout << "Enter product color: ";
        getline(cin, color);
        cout << "Enter material: ";
        getline(cin, material);
        cout << "Enter size: ";
        getline(cin, size);

        // Clothing object and print details
        Clothing clothing(name, brand, price, quantity, description, category, color, material, size);
        cout << "\nClothing details: \n\n" 
             << "Name:\t\t" << clothing.getName() << "\n" 
             << "Brand:\t\t" << clothing.getBrand() << "\n" 
             << "Price:\t\t" << clothing.getPrice() << "\n" 
             << "Quantity:\t" << clothing.getQuantity() << "\n" 
             << "Description:\t" << clothing.getDescription() << "\n" 
             << "Category:\t" << clothing.getCategory() << "\n" 
             << "Color:\t\t" << clothing.getColor() << "\n" 
             << "Material:\t" << clothing.getMaterial() << "\n" 
             << "Size:\t\t" << clothing.getSize() << endl;

    // Process Electronics type product
    } else if (productType == 'E' || productType == 'e') {
        // Input product details
        cout << "Enter product name: ";
        getline(cin, name);
        cout << "Enter product brand: ";
        getline(cin, brand);
        price = validatePositiveFloatInput("product price");
        quantity = validatePositiveIntegerInput("product quantity");
        cout << "Enter product description: ";
        getline(cin, description);
        cout << "Enter product category: ";
        getline(cin, category);
        cout << "Enter product color: ";
        getline(cin, color);
        cout << "Enter model: ";
        getline(cin, model);
        cout << "Enter warranty: ";
        getline(cin, warranty);
        cout << "Enter technical specifications: ";
        getline(cin, technicalSpecifications);

        // Electronics object and print details
        Electronics electronics(name, brand, price, quantity, description, category, color, model, warranty, technicalSpecifications);
        cout << "\nElectronics details:\n\n" 
             << "Name:\t\t" << electronics.getName() << "\n" 
             << "Brand:\t\t" << electronics.getBrand() << "\n" 
             << "Price:\t\t" << electronics.getPrice() << "\n" 
             << "Quantity:\t" << electronics.getQuantity() << "\n" 
             << "Description:\t" << electronics.getDescription() << "\n" 
             << "Category:\t" << electronics.getCategory() << "\n" 
             << "Color:\t\t" << electronics.getColor() << "\n" 
             << "Model:\t\t" << electronics.getModel() << "\n" 
             << "Warranty:\t" << electronics.getWarranty() << "\n" 
             << "\nTechnical Specifications:\t" << electronics.getTechnicalSpecifications() << endl;

    // Handle invalid product type
    } else {
        cout << "Invalid product type entered." << endl;
    }

    return 0;
}
