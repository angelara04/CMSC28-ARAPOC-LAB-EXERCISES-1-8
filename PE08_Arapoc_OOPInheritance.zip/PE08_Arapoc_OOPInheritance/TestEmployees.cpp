// Angel Grace P. Arapoc 
// Programming Exercise 08 - OOP 4 Inheritance
// May 29, 2024
// TestEmployee.cpp

#include "Employees.h"
#include <iostream>
#include <string>
#include <limits>
#include <algorithm>

using namespace std;

int main() {
    // Create object
    Employees e;
    string input;

    // Set attributes
    cout << "This program will collect information on employees.\n\nEnter employee's first name: ";
    getline(cin, input);
    e.setFname(input);

    cout << "Enter employee's last name: ";
    getline(cin, input);
    e.setLname(input);

    // Age validation
    int age = getValidInt("Enter employee's age: ");
    e.setage(age);

    // Gender validation
    char gender = getValidGender("Enter employee's gender (M/F): ");
    e.setgender(gender);

    cout << "Enter employee's email address: ";
    getline(cin, input);
    e.setEmailAdd(input);

    // Contact number validation
    int CpNum = getValidInt("Enter student's contact number: ");
    e.setCpNumber(to_string(CpNum));

    // Employee number validation
    int empNum = getValidInt("Enter employee's number: ");
    e.setEmpNum(to_string(empNum));

    cout << "Enter employee's position: ";
    getline(cin, input);
    e.setPosition(input);

    cout << "Enter employee's office: ";
    getline(cin, input);
    e.setOffice(input);

    // Salary validation
    double salary = getValidDouble("Enter employee's salary: ");
    e.setSalary(salary);

    // Get and print final statements using data inputted
    cout << "\nHi " << e.getFname() << " " << e.getLname() << "! Welcome to the OOP company!" << endl;
    cout << "You are appointed as a " << e.getPosition() << " in the " << e.getOffice() << " office." << endl;
    cout << "Your Employee Number is " << e.getEmpNum() << "." << endl;

    return 0;
}
