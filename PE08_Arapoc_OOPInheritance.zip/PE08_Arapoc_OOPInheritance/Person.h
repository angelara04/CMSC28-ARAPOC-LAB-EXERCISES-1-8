// Angel Grace P. Arapoc 
// Programming Exercise 08 - OOP 4 Inheritance
// May 29, 2024
// Person.h

#ifndef PERSON_H
#define PERSON_H

#include <iostream>
#include <string>
#include <limits>
#include <algorithm>

using namespace std;

class Person {
private:
    // Private data members
    int age;     
    char gender;   
    string fname; 
    string lname;

public:
    // Public data members
    string emailAdd;
    string cpNumber;

    // Default constructor
    Person() : age(0), gender('M') {}

    // Constructor with age parameter
    Person(int newage) : age(newage), gender('M') {}

    // Constructor with age and gender parameters
    Person(int newage, char c) : age(newage), gender(c) {}

    // Setter for age with input validation
    void setage(int newage) {
        if (newage >= 0) {
            age = newage;
        } else {
            cout << "Invalid age!!!" << endl;
        }
    }

    // Getter for age
    int getage() const {
        return age;
    }

    // Setter for gender with validation
    void setgender(char c) {
        if (c == 'M' || c == 'F') {
            gender = c;
        } else {
            cout << "Invalid gender!!!" << endl;
        }
    }

    // Getter for gender
    char getgender() const {
        return gender;
    }

    // Setter for email address
    void setEmailAdd(string email) {
        emailAdd = email;
    }

    // Getter for email address
    string getEmailAdd() const {
        return emailAdd;
    }

    // Setter for contact number with validation
    void setCpNumber(string number) {
        if (all_of(number.begin(), number.end(), ::isdigit)) {
            cpNumber = number;
        } else {
            cout << "Invalid contact number!!!" << endl;
        }
    }

    // Getter for contact number
    string getCpNumber() const {
        return cpNumber;
    }

    // Setter for first name
    void setFname(string name) {
        fname = name;
    }

    // Getter for first name
    string getFname() const {
        return fname;
    }

    // Setter for last name
    void setLname(string name) {
        lname = name;
    }

    // Getter for last name
    string getLname() const {
        return lname;
    }
};

// Function to validate integer input
int getValidInt(const string& prompt) {
    int value;
    while (true) {
        cout << prompt;
        cin >> value;
        if (cin.fail() || value < 0) { // check if input is invalid or negative
            cin.clear(); // clear the error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // discard invalid input
            cout << "Invalid input. Please enter a non-negative integer." << endl;
        } else {
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // clear any extra input
            return value;
        }
    }
}

//Functions for Input Validation
// Function to validate gender input
char getValidGender(const string& prompt) {
    char gender;
    while (true) {
        cout << prompt;
        cin >> gender;
        gender = toupper(gender);
        if (cin.fail() || (gender != 'M' && gender != 'F')) {
            cin.clear(); // clear the error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // discard invalid input
            cout << "Invalid input. Please enter 'M' or 'F'." << endl;
        } else {
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // clear any extra input
            return gender;
        }
    }
}

// Function to validate double input
double getValidDouble(const string& prompt) {
    double value;
    while (true) {
        cout << prompt;
        cin >> value;
        if (cin.fail() || value < 0) { // check if input is invalid or negative
            cin.clear(); // clear the error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // discard invalid input
            cout << "Invalid input. Please enter a non-negative number." << endl;
        } else {
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // clear any extra input
            return value;
        }
    }
}



#endif
