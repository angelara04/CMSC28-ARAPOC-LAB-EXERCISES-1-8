// Angel Grace P. Arapoc 
// Programming Exercise 08 - OOP 4 Inheritance
// May 29, 2024
// Employees.h
#ifndef EMPLOYEES_H
#define EMPLOYEES_H

#include "Person.h"
#include <algorithm>

class Employees : public Person {
private:
    //Private data members
    string empNum; // Employee number, string to allow characters like "-" and leading zeros

public:
    //Public data members
    string Position; 
    string Office; 
    double Salary; 

    // Setter for employee number
    void setEmpNum(const string& number) {
        if (all_of(number.begin(), number.end(), ::isdigit)) {
            empNum = number;
        } else {
            cout << "Invalid employee number!!!" << endl;
        }
    }

    // Getter for employee number
    string getEmpNum() const {
        return empNum;
    }

    // Setter for Position
    void setPosition(const string& position) {
        Position = position;
    }

    // Getter for Position
    string getPosition() const {
        return Position;
    }

    // Setter for Office
    void setOffice(const string& office) {
        Office = office;
    }

    // Getter for Office
    string getOffice() const {
        return Office;
    }

    // Setter for Salary
    void setSalary(double salary) {
        if (salary >= 0) {
            Salary = salary;
        } else {
            cout << "Invalid salary!!!" << endl;
        }
    }

    // Getter for Salary
    double getSalary() const {
        return Salary;
    }
};


#endif
