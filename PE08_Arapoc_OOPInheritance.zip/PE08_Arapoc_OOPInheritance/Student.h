// Angel Grace P. Arapoc 
// Programming Exercise 08 - OOP 4 Inheritance
// May 29, 2024
// Student.h
#ifndef STUDENT_H
#define STUDENT_H

#include "Person.h"

class Student : public Person {
private:
    // Private data members
    string studentNum; // Student number

public:
    // Public data members
    string Course;
    string Department; 
    string College; 

    // Setter for student number
    void setStudentNum(const string& number) {
        studentNum = number;
    }

    // Getter for student number
    string getStudentNum() const {
        return studentNum;
    }

    // Setter for course
    void setCourse(string course) {
        Course = course;
    }

    // Getter for course
    string getCourse() const {
        return Course;
    }

    // Setter for department
    void setDepartment(string department) {
        Department = department;
    }

    // Getter for department
    string getDepartment() const {
        return Department;
    }

    // Setter for college
    void setCollege(string college) {
        College = college;
    }

    // Getter for college
    string getCollege() const {
        return College;
    }
};


#endif
