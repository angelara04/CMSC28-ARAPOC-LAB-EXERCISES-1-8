// Angel Grace P. Arapoc 
// Programming Exercise 08 - OOP 4 Inheritance
// May 29, 2024
// TestStudent.cpp

#include "Student.h"
#include <iostream>
#include <string>

using namespace std;

//Main function
int main() {

    // Create object
    Student s;
    string input;

    // Set attributes
    cout << "This program will collect information on students.\n\nEnter student's first name: ";
    getline(cin, input);
    s.setFname(input);

    cout << "Enter student's last name: ";
    getline(cin, input);
    s.setLname(input);

    // Age validation
    int age = getValidInt("Enter student's age: ");
    s.setage(age);

    // Gender validation
    char gender = getValidGender("Enter student's gender (M/F): ");
    s.setgender(gender);

    cout << "Enter student's email address: ";
    getline(cin, input);
    s.setEmailAdd(input);

    // Contact number validation
    int CpNum = getValidInt("Enter student's contact number: ");
    s.setCpNumber(to_string(CpNum));

    // Student number validation
    int studentNum = getValidInt("Enter student's number: ");
    s.setStudentNum(to_string(studentNum));

    cout << "Enter student's course: ";
    getline(cin, input);
    s.setCourse(input);

    cout << "Enter student's department: ";
    getline(cin, input);
    s.setDepartment(input);

    cout << "Enter student's college: ";
    getline(cin, input);
    s.setCollege(input);

    // Get and print final statements using data inputted
    cout << "\nHi " << s.getFname() << " " << s.getLname() << "! Welcome to OOP University and congratulations! " << endl;
    cout << "We are pleased to inform you that you are admitted in the " << s.getCourse() << " program under the " << s.getDepartment() << "." << endl;
    cout << "Your Student Number is " << s.getStudentNum() << "." << endl;

    return 0;
}
